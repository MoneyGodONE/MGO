# MoneyGodONE Monorepo

Contains all apps and packages for the MGO ecosystem.
